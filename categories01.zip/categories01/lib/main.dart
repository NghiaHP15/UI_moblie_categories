import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            'Categories',
            style: TextStyle(
              color: Color.fromARGB(255, 26, 26, 26),
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Color.fromARGB(255, 255, 255, 255),
          actions: [
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.search),
              color: Colors.black,
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.favorite_border),
              color: Colors.black,
            ),
            IconButton(
              onPressed: () {},
              icon: const Icon(Icons.shopping_cart_outlined),
              color: Colors.black,
            ),
          ],
        ),
        body: const MyStatefulWidget(),
      ),
    );
  }
}

class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.fromLTRB(30, 30, 0, 0),
        child: Column(children: [
          Row(
            children: [
              Container(
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  ),
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/512/188/188987.png'),
                    backgroundColor: Color.fromARGB(255, 116, 242, 217),
                    radius: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                  ),
                  Text(
                    'Fashion',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  ),
                ]),
                width: 150,
                height: 140,
                decoration: BoxDecoration(
                    color: Color.fromARGB(255, 74, 184, 162),
                    borderRadius: BorderRadius.circular(14)),
              ),
              Padding(padding: const EdgeInsets.all(20)),
              Container(
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  ),
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/512/188/188987.png'),
                    backgroundColor: Color.fromARGB(255, 255, 208, 166),
                    radius: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                  ),
                  Text(
                    'Beauty',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  )
                ]),
                width: 150,
                height: 140,
                decoration: BoxDecoration(
                    color: Color.fromARGB(255, 252, 153, 67),
                    borderRadius: BorderRadius.circular(14)),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(10),
          ),
          Row(
            children: [
              Container(
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  ),
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/512/188/188987.png'),
                    backgroundColor: Color.fromARGB(255, 189, 165, 249),
                    radius: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                  ),
                  Text(
                    'Electronics ',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  )
                ]),
                width: 150,
                height: 140,
                decoration: BoxDecoration(
                    color: Color.fromARGB(255, 141, 96, 255),
                    borderRadius: BorderRadius.circular(14)),
              ),
              Padding(padding: const EdgeInsets.all(20)),
              Container(
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  ),
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/512/188/188987.png'),
                    backgroundColor: Color.fromARGB(255, 249, 168, 227),
                    radius: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                  ),
                  Text(
                    'Jewellery',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  )
                ]),
                width: 150,
                height: 140,
                decoration: BoxDecoration(
                    color: Color.fromARGB(255, 249, 84, 205),
                    borderRadius: BorderRadius.circular(14)),
              ),
            ],
          ),
          Padding(padding: const EdgeInsets.all(10)),
          Row(
            children: [
              Container(
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  ),
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/512/188/188987.png'),
                    backgroundColor: Color.fromARGB(255, 249, 149, 245),
                    radius: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                  ),
                  Text(
                    'Footwear',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  )
                ]),
                width: 150,
                height: 140,
                decoration: BoxDecoration(
                    color: Color.fromARGB(255, 175, 4, 170),
                    borderRadius: BorderRadius.circular(14)),
              ),
              Padding(padding: const EdgeInsets.all(20)),
              Container(
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  ),
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/512/188/188987.png'),
                    backgroundColor: Color.fromARGB(255, 146, 239, 248),
                    radius: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                  ),
                  Text(
                    'Toys',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  )
                ]),
                width: 150,
                height: 140,
                decoration: BoxDecoration(
                    color: Color.fromARGB(255, 0, 234, 255),
                    borderRadius: BorderRadius.circular(14)),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(10),
          ),
          Row(
            children: [
              Container(
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  ),
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/512/188/188987.png'),
                    backgroundColor: Color.fromARGB(255, 125, 247, 192),
                    radius: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                  ),
                  Text(
                    'Furniture',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  )
                ]),
                width: 150,
                height: 140,
                decoration: BoxDecoration(
                    color: Color.fromARGB(255, 4, 229, 128),
                    borderRadius: BorderRadius.circular(14)),
              ),
              Padding(padding: const EdgeInsets.all(20)),
              Container(
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 10, 0, 0),
                  ),
                  CircleAvatar(
                    backgroundImage: NetworkImage(
                        'https://cdn-icons-png.flaticon.com/512/188/188987.png'),
                    backgroundColor: Color.fromARGB(255, 237, 245, 174),
                    radius: 40,
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(0, 15, 0, 0),
                  ),
                  Text(
                    'Mobiles',
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 17),
                  )
                ]),
                width: 150,
                height: 140,
                decoration: BoxDecoration(
                    color: Color.fromARGB(255, 227, 247, 75),
                    borderRadius: BorderRadius.circular(14)),
              ),
            ],
          ),
        ]));
  }
}
